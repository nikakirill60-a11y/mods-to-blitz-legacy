60TP Lewandowskiego - мод для World of Tanks Blitz (legacy)
==========================================================

Архив уже разложен так, как нужно игре: распакуйте его СОДЕРЖИМОЕ
в корневую папку игры (туда, где находится папка assets/) и
подтвердите объединение папок.

  assets/tanks/poland_60tp.glb             модель танка
  assets/tanks/poland_60tp.png             основная текстура
  assets/tanks/poland_60tp_track.png       текстура гусениц
  assets/tanks/poland_60tp_icon.png        иконка в ангаре
  assets/data/tanks_mod/poland_60tp.tres   описание танка

Файлы .import не нужны: движок создаёт их сам при первом запуске.

После запуска игры танк появится в ангаре под именем
"60TP Lewandowskiego" (X уровень, европейская нация).

Настройка (по желанию) - в файле assets/data/tanks_mod/poland_60tp.tres:
  nation        нация: 1 СССР, 2 Германия, ... 9 Европа
  tree_branch   ветка дерева исследований
  prem          true = премиумный танк
  health, speed_limits, guns / engines / tracks - характеристики

Подробное описание мода, характеристик и пересборки модели -
в README.md папки mods/poland_60tp репозитория.
