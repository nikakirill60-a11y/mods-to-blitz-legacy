Waffentrager E 110 - мод для World of Tanks Blitz (legacy)
=========================================================

Архив уже разложен так, как нужно игре: распакуйте его СОДЕРЖИМОЕ
в корневую папку игры (туда, где находится папка assets/) и
подтвердите объединение папок.

  assets/tanks/germany_waffentrager_e110.glb         модель танка
  assets/tanks/germany_waffentrager_e110.png         основная текстура
  assets/tanks/germany_waffentrager_e110_track.png   текстура гусениц
  assets/tanks/germany_waffentrager_e110_light.png   текстура фар / люстры
  assets/tanks/germany_waffentrager_e110_icon.png    иконка в ангаре
  assets/data/tanks_mod/germany_waffentrager_e110.tres   описание танка

Файлы .import не нужны: движок создаёт их сам при первом запуске.

После запуска игры танк появится в ангаре под именем
"Waffentrager E 110" (X уровень, Германия, ПТ-САУ).

Характеристики (редактируются в .tres):
  прочность 1900, скорость 38 / -12 км/ч, масса 83 т
  орудие 12,8 cm Kw.K. 44 L/55 WM: 340/280 AP, 300/360 APCR,
  400/65 HE, перезарядка 8 с, углы -8/+14, поворот башни 15 град/с

Настройка (по желанию) - в файле
assets/data/tanks_mod/germany_waffentrager_e110.tres:
  nation              нация: 1 СССР, 2 Германия, ... 9 Европа
  tree_branch         ветка дерева исследований
  prem                true = премиумный танк
  turret_rot_speed    В РАДИАНАХ в секунду (15 град/с = 0.2618)
  health, speed_limits, guns / engines / tracks - характеристики

ВАЖНО: turret_rot_speed задаётся в радианах в секунду. Если вписать
туда 15, башня будет крутиться в 57 раз быстрее, чем нужно.

Подробное описание мода, характеристик и пересборки модели -
в README.md папки mods/germany_waffentrager_e110 репозитория.
