SCG/SC2 Viewer for WoT Blitz models (.sc2 / .scg / .dvpl)

1. Install Python 3 from python.org (tick 'Add python.exe to PATH'), if you do not have it.
2. Double-click SCGViewer.bat - the viewer window opens; drag a model or a folder into it.
   Or drop Tank.sc2.dvpl / Tank.scg.dvpl / a whole folder onto SCGViewer.bat.
3. Without Python: open scgviewer.html in Chrome/Edge/Firefox and drag the files in.

Console tool: scgtool.bat info|tree|mats|obj|json|unpack <file>
Full description (Russian): README.md
